# MyMC
Free Bootstrap template for Minecraft servers.

Click [here](http://rodymol123.github.io/MyMC/) for a demo.

## Pages

* Homepage
* Rules
* Staff
* Vote
* Link to your servers shop

## Bugs and Issues

Have a bug or an issue with this template? Open an issue or send us a message on [https://xtrada.nl/en/bug-report](http://xtrada.nl/en/bug-report)

## Creator

MyMC is maintained by **Rody Molenaar** from [Xtrada Nederland](https://xtrada.nl/en/).

* [Twitter](https://twitter.com/rodymolenaar)
* [GitHub](https://github.com/rodymol123)

Follow [@XtradaNL](https://twitter.com/XtradaNL) for more cool themes and templates!


## Copyright and License

Copyright 2015 Xtrada Nederland. Code released under the [Apache 2.0](http://www.apache.org/licenses/LICENSE-2.0) license.
